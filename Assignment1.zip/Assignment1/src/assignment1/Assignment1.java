/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment1;

import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 *
 * @author phani
 */
public class Assignment1 {
    
    SortedMap<Integer, String> sortedWords = new TreeMap<Integer, String>();
    
    //method to get the word with highest length
    public WordData getLongest(String input){
        
        String words[] = input.split(" ");
        
        for(String word : words){
            sortedWords.put(word.length(), word);
        }
        
        int lastKey = sortedWords.lastKey();
        
        WordData result =  new WordData(lastKey, sortedWords.get(lastKey));
               
        return result;
    }
    
    public static void main(String[] args) {
      Assignment1 a = new Assignment1();
      WordData res = a.getLongest("The show jumped over the moon");
      
        System.out.println("Longest word :" + res.getWord() + ", with length : " + res.getWordLength());
    }
    
}
