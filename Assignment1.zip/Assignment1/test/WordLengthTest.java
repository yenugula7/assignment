/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import assignment1.Assignment1;
import assignment1.WordData;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author phani
 */
public class WordLengthTest {
    
    public WordLengthTest() {
    }
    

    
    @Test
    public void testWordLength(){
        Assignment1 assg = new Assignment1();
        WordData expected = new WordData(6, "jumped");
        WordData actual = assg.getLongest("The show jumped over the moon");
        
        assertEquals(expected.getWord(), actual.getWord());
    }

}
